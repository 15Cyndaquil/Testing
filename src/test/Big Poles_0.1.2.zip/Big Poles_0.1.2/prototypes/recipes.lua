--
-- Created by IntelliJ IDEA.
-- User: Cyndaquil
-- Date: 6/13/2017
-- Time: 5:26 PM
-- To change this template use File | Settings | File Templates.
--

data:extend(
    {
        {
            type = "recipe",
            name = "bigger-electric-pole",
            ingredients = {
                {"steel-plate", 25},
                {"copper-plate", 25}
            },
            result = "bigger-electric-pole",
            enabled = true
        },
    }
)

