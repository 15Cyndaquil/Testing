--
-- Created by IntelliJ IDEA.
-- User: Cyndaquil
-- Date: 6/13/2017
-- Time: 5:30 PM
-- To change this template use File | Settings | File Templates.
--

data:extend(
    {
        {
            type = "item",
            name = "bigger-electric-pole",
            icon = "__base__/graphics/icons/big-electric-pole.png",
            flags = {"goes-to-quickbar"},
            subgroup = "energy-pipe-distribution",
            place_result = "bigger-electric-pole",
            stack_size = 50
        },
    }
)

